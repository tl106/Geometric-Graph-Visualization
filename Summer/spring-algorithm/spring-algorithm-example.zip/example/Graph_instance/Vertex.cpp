/*
 * Vertex.cpp
 *
 *  Created on: 27 Jun 2019
 *      Author: zy22101
 */

#include "Vertex.h"

Vertex::Vertex(string n)
:name(n)
{
    num_of_neighbour = 0;
}

string Vertex::getName() {

	return name;
}

vector<int> Vertex::getNeighbour() {

	return neighbour;
}

void Vertex::addNeighbour(int new_neighbour) {
	neighbour.push_back(new_neighbour);
	num_of_neighbour = neighbour.size();
}

int Vertex::getNumberOfNeighbour() {

	return num_of_neighbour;
}
