/*
 * DSPInstance.cpp
 *
 *  Created on: 27 Jun 2019
 *      Author: zy22101
 */

#include "DSPInstance.h"
#include <random>
#include <iostream>
#include <fstream>

void DSPInstance::setgraph(Graph * thegraph){
	graph = thegraph;
}

Graph* DSPInstance::getgraph(){
	return graph;
}
