#ifndef INSTANCE_VERTEX_H_
#define INSTANCE_VERTEX_H_

#include <string>
#include <vector>
using namespace std;

class Vertex {

private:
	string name;
	vector<int> neighbour;
    
public:
    double x;
    double y;
    int vid;
    int num_of_neighbour;
    
	Vertex(string n);
	string getName();
	vector<int> getNeighbour();
	void addNeighbour(int new_neighbour);
	int getNumberOfNeighbour();
};

#endif /* INSTANCE_VERTEX_H_ */
