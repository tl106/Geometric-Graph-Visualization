//
//  newkk.hpp
//  forceModel
//
//  Created by 王丹匀 on 2019/11/27.
//  Copyright © 2019 王丹匀. All rights reserved.
//

#ifndef Newkk_hpp
#define Newkk_hpp

#include <stdio.h>
#include <vector>
//#include "DSPInstanceReader.h"
#include "geometricFunctions.hpp"
//#include "main.hpp"

class Newkk {
public:
    struct Spring {
        double length;
        double strength;
    };
    
    Graph *g;
    double energy_threshold;
    vector<vector<Spring>> springs_;
    
    Newkk();
    Newkk(Graph *g, double k, double energy_threshold);
    
    static vector<vector<int>> floyd_warshall(Graph *g);
    void kk(vector<Point*> positions);
    double find_max_vertex_energy(vector<Point*> positions, int *max_energy_v_id);
    double compute_vertex_energy(int v_id, vector<Point*> positions);
    void compute_next_vertex_position(int v_id, vector<Point*> positions);
    Vector* compute_edgeRepulsion(int vid, vector<Point*> positions);
};

#endif /* Newkk_hpp */
